replace plymouth-shutdown.conf with
/etc/init/plymouth-shutdown.conf

